# bioSite
A personal bio website project for CSD 340 coursework.

## Contributors
<ul>
  <li>Pravin Bhandari</li>
  <li>Aurora Crippen</li>
</ul>